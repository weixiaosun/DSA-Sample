#ifndef SOLUTION_HPP_
#define SOLUTION_HPP_

#include <string>
#include <iostream>
#include <fstream>


template<class T>
class LN {
  public:
    LN ()                        : next(nullptr){}
    LN (const LN<T>& ln)         : value(ln.value), next(ln.next){}
    LN (T v, LN<T>* n = nullptr) : value(v), next(n){}
    T      value;
    LN<T>* next;
};


//Simple way to print linked lists (useful for driver and debugging)
template<class T>
std::ostream& operator << (std::ostream& outs, LN<T>* l) {
  for (LN<T>* p = l; p!=nullptr; p=p->next)
    outs << p->value << "->";
  outs << "nullptr";
  return outs;
}


//Simple way to print linked lists given first node
//  (useful for driver and debugging)
template<class T>
std::ostream& operator << (std::ostream& outs, LN<T> l) {
  outs << l.value << "->";
  for (LN<T>* p = l.next; p!=nullptr; p=p->next)
    outs << p->value << "->";
  outs << "nullptr";
  return outs;
}


char relation (const std::string& s1, const std::string& s2) {
	if      ( s1 == "" and s2 == "" ) return '=';
	else if ( s1 == "" and s2 != "" ) return '<';
	else if ( s1 != "" and s2 == "" ) return '>';
	else if (s1[0] != s2[0])      	  return s1[0] < s2[0] ? '<' : '>';
	else return relation( s1.substr(1), s2.substr(1) );
}


//Handle front and rest separately (each in their own loop)
//Line count is 12
template<class T>
void remove_ascending_i (LN<T>*& l) {
  while (l != nullptr && l->next != nullptr && l->value < l->next->value) {
    LN<T>* to_delete = l;
    l = l->next;
    delete to_delete;
  }
  for (LN<T>* p = nullptr, *c = l; c != nullptr && c->next != nullptr; /*see body*/)
    if (c->value < c->next->value) {
      LN<T>* to_delete = c;
      c = p->next = c->next;
      delete to_delete;
    }else{
      p = c;
      c = c->next;
    }

}

//Handle front and rest the same (both in one loop with conditional expression):
//Line count is 8
//template<class T>
//void remove_ascending_i (LN<T>*& l) {
//  for (LN<T>* p = nullptr, *c = l; c != nullptr && c->next != nullptr; /*see body*/)
//    if (c->value < c->next->value) {
//      LN<T>* to_delete = c;
//      c = (c == l ? l : p->next) = c->next;  //An interesting use of (?:) as a left-hand side
//      delete to_delete;
//    }else{
//      p = c;
//      c = c->next;
//    }
//}

//Handle removal at front by copy-back of next values
//Line count is 7, but
//template<class T>
//void remove_ascending_i (LN<T>*& l) {
//  for (LN<T>* c = l; c != nullptr && c->next != nullptr; /*see body*/)
//    if (c->value < c->next->value) {
//      LN<T>* to_delete = c->next;
//      *c = *(c->next);
//      delete to_delete;
//    }else
//      c = c->next;
//}

//Use pointer to pointer, using on loop
//Statement count is 7
//template<class T>
//void remove_ascending_i (LN<T>*& l) {
//  for (LN<T>** p = &l; *p != nullptr && (*p)->next != nullptr; /*see body*/)
//    if ((*p)->value < (*p)->next->value) {
//      LN<T>* to_delete = *p;
//      (*p) = (*p)->next;
//      delete to_delete;
//    }else
//      p = &((*p)->next);
//}


//Straight-forward recursion
//Statement count is 11
template<class T>
void remove_ascending_r (LN<T>*& l) {
  if (l == nullptr || l->next == nullptr)
    return;
  else {
    if (l->value >= l->next->value)
      remove_ascending_r(l->next);
    else{
      LN<T>* to_delete = l;
      l = l->next;
      delete to_delete;
      remove_ascending_r(l);
    }
  }
}



#endif /* SOLUTION_HPP_ */
